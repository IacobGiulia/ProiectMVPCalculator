﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Printing;
using System.Globalization;
using System.Windows;

namespace Tema1_Calculator
{
    public class CalculatorViewModel: INotifyPropertyChanged
    {
        private readonly Calculator _calculator = new Calculator();
        private string _displayText = "0";
        private HashSet<char> allowedDigits = new HashSet<char>("0123456789ABCDEF");

        private bool _isDigitGroupingEnabled = false;

        public bool IsDigitGroupingEnabled
        {
            get { return _isDigitGroupingEnabled;  }
            set
            {
                _isDigitGroupingEnabled = value;
                OnPropertyChanged(nameof(IsDigitGroupingEnabled));
                OnPropertyChanged(nameof(DisplayText));
            }
        }

        public string DisplayText
        {
            get
            {
                if (double.TryParse(_displayText, NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands,
                                    CultureInfo.InvariantCulture, out double number))
                {
                    if (number % 1 == 0)
                        return IsDigitGroupingEnabled
                            ? number.ToString("N0", CultureInfo.InvariantCulture) 
                            : number.ToString(CultureInfo.InvariantCulture); 

                    return number.ToString("G", CultureInfo.InvariantCulture);
                }
                return _displayText;
            }
            set
            {
                _displayText = value;
                OnPropertyChanged();
            }
        }

        private string selectedBase;
        public string SelectedBase
        {
            get { return selectedBase; }
            set
            {
                selectedBase = value;
                OnPropertyChanged(nameof(SelectedBase));
                UpdateAllowedDigits(); // Actualizează cifrele permise
            }
        }

        public void AppendDecimalPoint()
        {
            _calculator.AppendDecimalPoint();
            DisplayText = _calculator.Input;
        }
        public void AppendNumber(string number)
        {
            _calculator.AppendNumber(number);
            DisplayText = _calculator.Input;
            OnPropertyChanged(nameof(DisplayText));
        }

        public void SetOperation(string op)
        {
            _calculator.setOperation(op);
            DisplayText = _calculator.Input;
        }

        public void Calculate()
        {
            DisplayText = _calculator.Calculate();
            OnPropertyChanged(nameof(DisplayText));
        }

        public void Square()
        {
            DisplayText = _calculator.Square();
        }

        public void MultiplicativeInverse()
        {
            DisplayText = _calculator.MultiplicativeInverse();
        }

        public void SquareRoot()
        {
            DisplayText = _calculator.SquareRoot();
        }

        public void PlusMinus()
        {
            DisplayText = _calculator.PlusMinus();
        }
        public void Clear()
        {
            _calculator.Clear();
            DisplayText = "0";
        }

        public void ClearEntry()
        {
            _calculator.ClearEntry();
            DisplayText = "0";
        }

        public void MemoryClear()
        {
            _calculator.MemoryClear();
        }

        public void MemoryRecall()
        {
            DisplayText = _calculator.MemoryRecall(); 
        }

        public void MemoryAdd()
        {
            _calculator.MemoryAdd();
        }

        public void MemorySubstract()
        {
            _calculator.MemorySubstract();
        }

        public void MemoryStore()
        {
            _calculator.MemoryStore();
        }

        //public void MemoryView()
        //{
        //    DisplayText = _calculator.MemoryView();
        //}

        public void OpenMemoryView()
        {
            List<double> memoryValues = _calculator.MemoryView();
            MemoryViewWindow memoryWindow = new MemoryViewWindow(memoryValues, _calculator);

            if(memoryWindow.ShowDialog() == true)
            {
                DisplayText = memoryWindow.SelectedValue.ToString();
            }
        }
        public void Backspace()
        {
            _calculator.Backspace();
            DisplayText = _calculator.Input;

        }

        public bool IsDigitEnabled(string digit)
        {
            return allowedDigits.Contains(digit[0]);
        }

        private void UpdateAllowedDigits()
        {
            switch (selectedBase)
            {
                case "BIN": allowedDigits = new HashSet<char>("01"); break;
                case "OCT": allowedDigits = new HashSet<char>("01234567"); break;
                case "DEC": allowedDigits = new HashSet<char>("0123456789"); break;
                case "HEX": allowedDigits = new HashSet<char>("0123456789ABCDEF"); break;
            }

            
            OnPropertyChanged(nameof(allowedDigits));
        }

        public void SwitchBase(string baseType)
        {
            try
            {
                // Detectăm baza curentă și convertim numărul la decimal
                int number = selectedBase switch
                {
                    "BIN" => Convert.ToInt32(_displayText, 2),   // Convertire din binar
                    "OCT" => Convert.ToInt32(_displayText, 8),   // Convertire din octal
                    "HEX" => Convert.ToInt32(_displayText, 16),  // Convertire din hex
                    _ => int.Parse(_displayText)                 // Default: decimal
                };

                // Convertim numărul decimal în noua bază
                DisplayText = baseType switch
                {
                    "BIN" => Convert.ToString(number, 2),   // Conversie în binar
                    "OCT" => Convert.ToString(number, 8),   // Conversie în octal
                    "DEC" => number.ToString(),             // Decimal rămâne la fel
                    "HEX" => Convert.ToString(number, 16).ToUpper(), // Conversie în hex
                    _ => DisplayText
                };

                SelectedBase = baseType; // Setăm noua bază
                UpdateAllowedDigits(); // Actualizăm cifrele permise
                OnPropertyChanged(nameof(DisplayText)); // Notificăm interfața să se actualizeze
            }
            catch (Exception)
            {
                DisplayText = "ERROR"; // Dacă există o eroare, afișăm un mesaj
            }
        }

        private void SetBase(string newBase)
        {
            SelectedBase = newBase;
           
        }

        public void CopyToClipboard()
        {
            if(!string.IsNullOrEmpty(DisplayText))
            {
                Clipboard.SetText(DisplayText);
            }
        }

        public void PasteFromClipboard()
        {
            if(Clipboard.ContainsText())
            {
                string text = Clipboard.GetText();
                if (int.TryParse(text, out _)) // Verificăm dacă este un număr valid
                {
                    DisplayText = text;
                }
            }
        }

        public void CutToClipboard()
        {
            if (!string.IsNullOrEmpty(DisplayText))
            {
                Clipboard.SetText(DisplayText);
                DisplayText = "0"; // Ștergem numărul din display după "Cut"
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

}
