﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tema1_Calculator;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private readonly CalculatorViewModel _viewModel = new CalculatorViewModel();
    private string input = "";
    //private MainWindow mainWindow;
    public MainWindow()
    {
        InitializeComponent();
        DataContext = _viewModel;
        this.KeyDown += MainWindow_KeyDown;
    }
    private void Number_Click(object sender, RoutedEventArgs e)
    {
        var button = sender as System.Windows.Controls.Button;
        _viewModel.AppendNumber(button.Content.ToString());
    }

    private void Operation_Click(object sender, RoutedEventArgs e)
    {
        var button = sender as System.Windows.Controls.Button;
        _viewModel.SetOperation(button.Content.ToString());
    }

    private void Equals_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.Calculate();
    }

    private void Clear_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.Clear();
    }

    private void Square_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.Square();
    }

    private void MultiplicativeInverse_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.MultiplicativeInverse();
    }

    private void SquareRoot_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.SquareRoot();
    }

    private void Backspace_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.Backspace();
    }

    private void Plus_Minus_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.PlusMinus();
    }
    private void Clear_Entry_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.ClearEntry();
    }
    private void Clear_Memory_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.MemoryClear();
    }
    
    private void Memory_Recall_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.MemoryRecall();
    }

    private void Memory_Add_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.MemoryAdd();
    }

    private void Memory_Substract_Click(object sedner, RoutedEventArgs e)
    {
        _viewModel.MemorySubstract();
    }

    private void Memory_Store_Click(object sedner, RoutedEventArgs e)
    {
        _viewModel.MemoryStore();
    }

    //private void Memory_View_Click(object sender, RoutedEventArgs e)
    //{
    //    _viewModel.MemoryView();
    //}

    private void OpenMemoryView(object sender, RoutedEventArgs e)
    {
        _viewModel.OpenMemoryView();
    }

    private void Decimal_Point_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.AppendDecimalPoint();
    }

    private void Copy_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.CopyToClipboard();
    }

    private void Paste_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.PasteFromClipboard();
    }

    private void Cut_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.CutToClipboard();
    }

    private void Digit_Grouping_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.IsDigitGroupingEnabled = !_viewModel.IsDigitGroupingEnabled;
    }

    private void Show_Name_Click(object sender, RoutedEventArgs e)
    {
        MessageBox.Show("Iacob Giulia, grupa 10LF331", "About", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void MainWindow_KeyDown(object sender, KeyEventArgs e)
    {
        if (DataContext is CalculatorViewModel viewModel)
        {
            if (e.Handled) return;
            switch (e.Key)
            {
                case Key.D0: case Key.NumPad0: viewModel.AppendNumber("0"); break;
                case Key.D1: case Key.NumPad1: viewModel.AppendNumber("1"); break;
                case Key.D2: case Key.NumPad2: viewModel.AppendNumber("2"); break;
                case Key.D3: case Key.NumPad3: viewModel.AppendNumber("3"); break;
                case Key.D4: case Key.NumPad4: viewModel.AppendNumber("4"); break;
                case Key.D5: case Key.NumPad5: viewModel.AppendNumber("5"); break;
                case Key.D6: case Key.NumPad6: viewModel.AppendNumber("6"); break;
                case Key.D7: case Key.NumPad7: viewModel.AppendNumber("7"); break;
                case Key.D8: case Key.NumPad8: viewModel.AppendNumber("8"); break;
                case Key.D9: case Key.NumPad9: viewModel.AppendNumber("9"); break;
                case Key.OemPeriod: case Key.Decimal: viewModel.AppendDecimalPoint(); break;

                case Key.Add: case Key.OemPlus: viewModel.SetOperation("+"); break;
                case Key.Subtract: case Key.OemMinus: viewModel.SetOperation("-"); break;
                case Key.Multiply: viewModel.SetOperation("×"); break;
                case Key.Divide: case Key.Oem2: viewModel.SetOperation("÷"); break;

                case Key.Enter: viewModel.Calculate(); break;
                case Key.Back: viewModel.Backspace(); break;
                case Key.Delete: viewModel.Clear(); break;

                case Key.Escape: viewModel.ClearEntry(); break;
            }
            e.Handled = true;
        }
    }

    private void SwitchToProgrammer_Click(object sender, RoutedEventArgs e)
    {
        SecondWindow ProgrammerWindow = new SecondWindow();
        ProgrammerWindow.Show();
        this.Hide();
    }
}