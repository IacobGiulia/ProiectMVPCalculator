﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Tema1_Calculator
{
    public class Calculator
    {
        private double firstNumber;
        private string operation;
        private string input = "";
        private Stack<double> memoryStack = new Stack<double>();
        private string lastOperator = "";
        private double currentValue = 0;


        public string Input => input;

        public double GetCurrentValue()
        {
            return double.TryParse(input, out double number) ? number : 0;
        }
        public void AppendNumber(string number)
        {
            if (input == "0")
                input = number;
            else
                input += number;
        }
        public void AppendDecimalPoint()
        {
            if (!input.Contains("."))
            {
                if (string.IsNullOrEmpty(input))
                {
                    input = "0.";
                }
                else
                {
                    input += ".";
                }

            }
        }

        public void setOperation(string op)
        {
            if(!string.IsNullOrEmpty(lastOperator))
            {
                input = Calculate();
                currentValue = double.Parse(input);
            }
            else
            {
                currentValue = double.Parse(input);
            }
            lastOperator = op;
            input = "0";

        }

        public string Calculate()
        {
            double newValue = double.Parse(input);

            switch (lastOperator)
            {
                case "+":
                    currentValue += newValue;
                    break;
                case "-":
                    currentValue -= newValue;
                    break;
                case "×":
                    currentValue *= newValue;
                    break;
                case "%":
                    currentValue = currentValue * newValue / 100;
                    break;
                case "÷":
                    if (newValue != 0)
                        currentValue /= newValue;
                    else
                        return "Eroare"; 
                    break;
            }

            lastOperator = ""; // Resetăm operatorul după finalizarea calculelor
            input = currentValue.ToString();
            return input;
        }
        public string Square()
        {
            if(double.TryParse(input, out double number))
            {
                double result = Math.Pow(number, 2);
                input = result.ToString();
                return input;
            }
            return "Error";
        }

        public string MultiplicativeInverse()
        {
            if(double.TryParse(input, out double number))
            {
                double result = 1 / number;
                input = result.ToString();
                return input;
            }
            return "Error";
        }

        public string SquareRoot()
        {
            if (double.TryParse(input, out double number))
            {
                double result = Math.Sqrt(number);
                input = result.ToString();
                return input;
            }
            return "Error";
        }

        public string PlusMinus()
        {
            if(double.TryParse(input, out double number))
            {
                double result = (-1) * (number);
                input = result.ToString();
                return input;
            }
            return "Error";
        }
        public void Clear()
        {
            input = "";
            firstNumber = 0;
            operation = "";
        }

        public void ClearEntry()
        {
            input = "";
        }

        public void MemoryClear()
        {
            memoryStack.Clear();
        }

        public string MemoryRecall()
        {
            if(memoryStack.Count > 0)
            {
                input = memoryStack.Peek().ToString();
            }
            return input;
        }

        public void MemoryAdd()
        {
            if(memoryStack.Count>0 && double.TryParse(input, out double number))
            {
                double last = memoryStack.Pop();
                memoryStack.Push(last + number);
            }
        }

        public void MemorySubstract()
        {
            if(memoryStack.Count > 0 && double.TryParse(input, out double number))
            {
                double last = memoryStack.Pop();
                memoryStack.Push(last - number);
            }
        }

        public void MemoryStore()
        {
            if(double.TryParse(input, out double number))
            {
                memoryStack.Push(number);
            }
        }

        public List<double> MemoryView()
        {
            return memoryStack.ToList();
        }

        public void Backspace()
        {
            if(!string.IsNullOrEmpty(input))
            {
                input = input.Substring(0, input.Length - 1);
            }
        }
    }
}
