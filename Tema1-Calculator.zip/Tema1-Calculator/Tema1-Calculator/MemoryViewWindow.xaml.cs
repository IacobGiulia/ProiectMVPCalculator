﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Tema1_Calculator
{
    /// <summary>
    /// Interaction logic for MemoryViewWindow.xaml
    /// </summary>
    public partial class MemoryViewWindow : Window
    {
        public double SelectedValue { get; set; }
        private List<double> memoryValues;
        private Calculator calculator;

        public MemoryViewWindow(List <double> memoryValues, Calculator calculator)
        {
            InitializeComponent();
            this.memoryValues = memoryValues;
            this.calculator = calculator;
            MemoryList.ItemsSource = memoryValues;
        }

        private void SelectMemoryValue(object sender, RoutedEventArgs e)
        {
            if(MemoryList.SelectedItems != null)
            {
                SelectedValue = (double)MemoryList.SelectedItem;
                DialogResult = true;
                Close();
            }
        }

        private void MemoryAdd(object sender, RoutedEventArgs e)
        {
            if (MemoryList.SelectedItem != null)
            {
                int index = MemoryList.SelectedIndex;
                memoryValues[index] += calculator.GetCurrentValue();
                RefreshMemory();
            }
        }

        private void MemorySubtract(object sender, RoutedEventArgs e)
        {
            if (MemoryList.SelectedItem != null)
            {
                int index = MemoryList.SelectedIndex;
                memoryValues[index] -= calculator.GetCurrentValue();
                RefreshMemory();
            }
        }

        private void MemoryClear(object sender, RoutedEventArgs e)
        {
            if (MemoryList.SelectedItem != null)
            {
                memoryValues.Remove((double)MemoryList.SelectedItem); 
                RefreshMemory();
            }
        }

        private void RefreshMemory()
        {
            MemoryList.ItemsSource = null;
            MemoryList.ItemsSource = memoryValues;
        }
    }
}
