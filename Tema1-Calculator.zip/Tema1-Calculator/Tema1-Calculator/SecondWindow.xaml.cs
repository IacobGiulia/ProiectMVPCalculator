﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Tema1_Calculator
{
    /// <summary>
    /// Interaction logic for SecondWindow.xaml
    /// </summary>
    public partial class SecondWindow : Window
    {
        private MainWindow mainWindow;
        private readonly CalculatorViewModel _viewModel = new CalculatorViewModel();

        public SecondWindow()
        {
            InitializeComponent();
            DataContext = _viewModel;
        }

        private void Number_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as System.Windows.Controls.Button;
            _viewModel.AppendNumber(button.Content.ToString());
        }

        private void Operation_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as System.Windows.Controls.Button;
            _viewModel.SetOperation(button.Content.ToString());
        }

        private void Equals_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.Calculate();
        }

        private void Backspace_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.Backspace();
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.Clear();
        }

        private void SwitchToStandard_Click(object sender, RoutedEventArgs e)
        {
            MainWindow StandardWindow = new MainWindow();
            StandardWindow.Show();
            this.Hide();
            
        }

        private void Bin_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.SwitchBase("BIN");
            UpdateButtonStates();
        }

        private void Oct_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.SwitchBase("OCT");
            UpdateButtonStates();
        }

        private void Dec_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.SwitchBase("DEC");
            UpdateButtonStates();
        }

        private void Hex_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.SwitchBase("HEX");
            UpdateButtonStates();
        }

        private void UpdateButtonStates()
        {
            Button0.IsEnabled = _viewModel.IsDigitEnabled("0");
            Button1.IsEnabled = _viewModel.IsDigitEnabled("1");
            Button2.IsEnabled = _viewModel.IsDigitEnabled("2");
            Button3.IsEnabled = _viewModel.IsDigitEnabled("3");
            Button4.IsEnabled = _viewModel.IsDigitEnabled("4");
            Button5.IsEnabled = _viewModel.IsDigitEnabled("5");
            Button6.IsEnabled = _viewModel.IsDigitEnabled("6");
            Button7.IsEnabled = _viewModel.IsDigitEnabled("7");
            Button8.IsEnabled = _viewModel.IsDigitEnabled("8");
            Button9.IsEnabled = _viewModel.IsDigitEnabled("9");
            ButtonA.IsEnabled = _viewModel.IsDigitEnabled("A");
            ButtonB.IsEnabled = _viewModel.IsDigitEnabled("B");
            ButtonC.IsEnabled = _viewModel.IsDigitEnabled("C");
            ButtonD.IsEnabled = _viewModel.IsDigitEnabled("D");
            ButtonE.IsEnabled = _viewModel.IsDigitEnabled("E");
            ButtonF.IsEnabled = _viewModel.IsDigitEnabled("F");
        }
    }



}
